import {AfterViewInit, Component, Inject, OnDestroy, OnInit, Type} from '@angular/core';
import {TabComponent} from '../tab/tab.component';
import {MAT_DIALOG_DATA, MatDialog, MatDialogConfig, MatDialogRef} from '@angular/material';
import {ProductSearch} from '../obj/product-search';
import {FormBuilder, FormGroup} from '@angular/forms';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent  implements OnInit, AfterViewInit, OnDestroy {

  value: string;

  title: string;

  productSearch: ProductSearch;

  columnDefs = [
    {
      headerName: "Athlete Details",
      children: [
        {
          headerName: "Athlete",
          field: "athlete",
          width: 150,
          filter: "agTextColumnFilter"
        },
        {
          headerName: "Age",
          field: "age",
          width: 90,
          filter: "agNumberColumnFilter"
        },
        {
          headerName: "Country",
          field: "country",
          width: 120
        }
      ]
    },
    {
      headerName: "Sports Results",
      children: [
        {
          headerName: "Sport",
          field: "sport",
          width: 110
        },
        {
          headerName: "Total",
          columnGroupShow: "closed",
          field: "total",
          width: 100,
          filter: "agNumberColumnFilter"
        },
        {
          headerName: "Gold",
          columnGroupShow: "open",
          field: "gold",
          width: 100,
          filter: "agNumberColumnFilter"
        },
        {
          headerName: "Silver",
          columnGroupShow: "open",
          field: "silver",
          width: 100,
          filter: "agNumberColumnFilter"
        },
        {
          headerName: "Bronze",
          columnGroupShow: "open",
          field: "bronze",
          width: 100,
          filter: "agNumberColumnFilter"
        }
      ]
    }];


    rowData = [];


  rowNewData = [
    { make: 'Toyota', model: 'Celica1', price: 999 },
    { make: 'Ford', model: 'Mondeo1', price: 999 },
    { make: 'Porsche', model: 'Boxter1', price: 999 }
  ];
  private gridApi;
  private gridColumnApi;

  rowSelection: string;
  constructor(public dialog: MatDialog, private http: HttpClient) {

  }

  editProduct(data: any): void {
    const selectedRows = this.gridApi.getSelectedRows();
    const selectedRowsString = '';

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '800px';

    dialogConfig.data = {
      id: 1,
      title: 'Angular For Beginners',
      description: 'fdasfads'
    };

    this.productSearch = new ProductSearch();
    let dialogRef = this.dialog.open(ProductEditDialogComponent, dialogConfig);

    dialogRef.afterClosed().subscribe((result: any) => {
      console.log('The dialog was closed');
    //  this.rowData = this.rowNewData;

      //  this.gridApi.refreshCells();

    });

  }
  ngOnInit() {
    this.value = 'fdasF';
    this.title = 'Product';
    this.rowSelection = 'single';
    console.log("init");
    this.rowData = [
      { make: 'Toyota', model: 'Celica1', price: 999 },
      { make: 'Ford', model: 'Mondeo1', price: 999 },
      { make: 'Porsche', model: 'Boxter1', price: 999 }
    ];


  }

  update(): void {
    this.http
      .get("https://raw.githubusercontent.com/ag-grid/ag-grid-docs/master/src/olympicWinnersSmall.json")
      .subscribe((data:any[]) => {
        this.rowData = data;
      });

  }



  searchtest() : void {
    this.update();
  }

  ngAfterViewInit(): void {

  }

  search(): void {
    this.productSearch = new ProductSearch();
    let dialogRef = this.dialog.open(ProductSearchDialogComponent, {
      width: '800px',
      data: this.productSearch,
      hasBackdrop: true
    });

    dialogRef.afterClosed().subscribe((result: ProductSearch) => {
      console.log('The dialog was closed');
      this.rowData = this.rowNewData;

    //  this.gridApi.refreshCells();

    });
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

  //  this.gridApi.setRowHeight(100);
  }

  ngOnDestroy(): void {
    console.log("destroy");
  }
}


@Component({
  selector: 'app-product-search-dialog',
  templateUrl: 'product-search-dialog.component.html',
})
export class ProductSearchDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<ProductSearchDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public productSearch: ProductSearch) { }


}

@Component({
  selector: 'app-product-edit-dialog',
  templateUrl: 'product-edit-dialog.component.html',
})
export class ProductEditDialogComponent implements OnInit{

  form: FormGroup;
  description: string;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<ProductEditDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {

    this.description = data.description;
  }

  ngOnInit(): void {


    this.form = this.fb.group({
      description: [this.description, []],
    });
  }

  save() {
    this.dialogRef.close(this.form.value);
  }

  close() {
    this.dialogRef.close();
  }


}

