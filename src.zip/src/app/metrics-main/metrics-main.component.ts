import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';
import {TabComponent} from '../tab/tab.component';

@Component({
  selector: 'app-metrics-main',
  templateUrl: './metrics-main.component.html',
  styleUrls: ['./metrics-main.component.css']
})
export class MetricsMainComponent implements OnInit {

  tabs = ['First', 'Second', 'Third'];
  selected = new FormControl(0);
  constructor() {
  }

  ngOnInit() {
  }



}
