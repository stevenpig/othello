import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MetricsMainComponent } from './metrics-main.component';

describe('MetricsMainComponent', () => {
  let component: MetricsMainComponent;
  let fixture: ComponentFixture<MetricsMainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MetricsMainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MetricsMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
