/**
 * The main component that renders single TabComponent
 * instances.
 */

import {
  Component,
  ContentChildren,
  QueryList,
  AfterContentInit,
  ViewChild,
  ComponentFactoryResolver,
  ViewContainerRef, OnInit, AfterViewInit, ContentChild
} from '@angular/core';

import { DynamicTabsDirective } from './dynamic-tabs.directive';
import {TabComponent} from './tab.component';
import {ProductComponent} from '../product/product.component';
import {EvComponentComponent} from '../ev-component/ev-component.component';
import {MatTab} from '@angular/material';
import {Tab} from './tab';
import {TabServiceService} from '../service/tab-service.service';

@Component({
  selector: 'app-tabs',
  template: `
    <mat-tab-group (selectedTabChange)="searchtest('Product')">


      <mat-tab *ngFor='let tab of tabs' id="tab.title" >
        <ng-template mat-tab-label>
          <button mat-icon-button [matMenuTriggerFor]="menu">
            <mat-icon>more_vert</mat-icon>
          </button>
          <mat-menu #menu="matMenu">
            <button mat-menu-item (click)="searchTab(tab.title)">
              <mat-icon>search</mat-icon>
              <span>Search</span>
            </button>
            <button mat-menu-item>
              <mat-icon>add</mat-icon>
              <span>Add</span>
            </button>
          </mat-menu>

          <span>{{tab.title}}</span>
        </ng-template>
        <app-tab [component]="tab.component" [title]="tab.title" ></app-tab>
      </mat-tab>
    </mat-tab-group>

  `,
  styles: [
    `
    .tab-close {
      color: gray;
      text-align: right;
      cursor: pointer;
    }
    `
  ]
})
export class TabsComponent implements OnInit, AfterViewInit, AfterContentInit {


  @ContentChild(MatTab) tab: MatTab;

  tabs: Tab[] = [
    {data: null, title: 'Product', component: ProductComponent},
    {data: null, title: 'Component', component: EvComponentComponent},


  ];

  /*
    Alternative approach of using an anchor directive
    would be to simply get hold of a template variable
    as follows
  */
  // @ViewChild('container', {read: ViewContainerRef}) dynamicTabPlaceholder;

  constructor(private componentFactoryResolver: ComponentFactoryResolver, private tabService: TabServiceService) {}

  loadComponent() {





  }
  searchtest(title: string) : void {
    this.tabService.getComponent(title).searchtest();
  }
  searchTab(title: string) {

    this.tabService.getComponent(title).search(title);
  }

  ngOnInit() {
    this.loadComponent();
  }

  ngAfterViewInit(): void {


  }

  ngAfterContentInit(): void {


  }

  /*
    // contentChildren are set
    ngAfterContentInit() {


      // get all active tabs
      const activeTabs = this.tabs.filter(tab => tab.active);

      // if there is no active tab set, activate the first
      if (activeTabs.length === 0) {
        this.selectTab(this.tabs.first);
      }

  }

  openTab(title: string, template, data, isCloseable = false) {
    // get a component factory for our TabComponent
    const componentFactory = this._componentFactoryResolver.resolveComponentFactory(
      TabComponent
    );

    // fetch the view container reference from our anchor directive
    const viewContainerRef = this.dynamicTabPlaceholder.viewContainer;

    // alternatively...
    // let viewContainerRef = this.dynamicTabPlaceholder;

    // create a component instance
    const componentRef = viewContainerRef.createComponent(componentFactory);

    // set the according properties on our component instance
    const instance: TabComponent = componentRef.instance as TabComponent;
    instance.title = title;


    // remember the dynamic component for rendering the
    // tab navigation headers
    this.dynamicTabs.push(componentRef.instance as TabComponent);

    // set it active
    this.selectTab(this.dynamicTabs[this.dynamicTabs.length - 1]);
  }

  selectTab(tab: TabComponent) {
    // deactivate all tabs
    this.tabs.toArray().forEach(tab => (tab.active = false));
    this.dynamicTabs.forEach(tab => (tab.active = false));

    // activate the tab the user has clicked on.
    tab.active = true;
  }

  closeTab(tab: TabComponent) {
    for (let i = 0; i < this.dynamicTabs.length; i++) {
      if (this.dynamicTabs[i] === tab) {
        // remove the tab from our array
        this.dynamicTabs.splice(i, 1);

        // destroy our dynamically created component again
        let viewContainerRef = this.dynamicTabPlaceholder.viewContainer;
        // let viewContainerRef = this.dynamicTabPlaceholder;
        viewContainerRef.remove(i);

        // set tab index to 1st one
        this.selectTab(this.tabs.first);
        break;
      }
    }
  }

  closeActiveTab() {
    const activeTabs = this.dynamicTabs.filter(tab => tab.active);
    if (activeTabs.length > 0) {
      // close the 1st active tab (should only be one at a time)
      this.closeTab(activeTabs[0]);
    }
  }

  */
}
