/**
 * A single tab page. It renders the passed template
 * via the @Input properties by using the ngTemplateOutlet
 * and ngOutletContext directives.
 */

import {AfterContentInit, AfterViewInit, Component, ComponentFactoryResolver, Input, Type, ViewChild} from '@angular/core';
import {DynamicTabsDirective} from './dynamic-tabs.directive';
import {ProductComponent} from '../product/product.component';
import {EvComponentComponent} from '../ev-component/ev-component.component';
import {Tab} from './tab';
import {TabServiceService} from '../service/tab-service.service';

@Component({
  selector: 'app-tab',
  styles: [
    `
    .pane{
      padding: 1em;
    }
  `
  ],
  template: `
    <ng-template appDynamicTab></ng-template>
  `
})
export class TabComponent implements AfterContentInit{

  constructor(private componentFactoryResolver: ComponentFactoryResolver, private tabService: TabServiceService) {}

  @Input('component') component: Type<any>;

  @Input('title') title: string;

  @ViewChild(DynamicTabsDirective) dynamicTabPlaceholder: DynamicTabsDirective;

  ngAfterContentInit(): void {

    const viewContainerRef = this.dynamicTabPlaceholder.viewContainer;


    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(this.component);

    const componentRef = viewContainerRef.createComponent(componentFactory);

    const instance: TabComponent = componentRef.instance as TabComponent;

    this.tabService.addComponent(instance);

  }

  search(title: string): void {

  }

  searchtest() : void {

  }

}
