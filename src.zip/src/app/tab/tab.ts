import {Type} from '@angular/core';


export interface Tab {


  data?: any;
  title: string;
  component: Type<any>;
}
