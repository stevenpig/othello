import { Injectable } from '@angular/core';
import {TabComponent} from '../tab/tab.component';

@Injectable({
  providedIn: 'root'
})
export class TabServiceService {

  tabComponents: TabComponent[] = [];

  constructor() { }

  addComponent(tabComponent: TabComponent): void {
    this.tabComponents.push(tabComponent);
  }

  getComponent(title: string): TabComponent {
    return this.tabComponents.find(t => t.title === title);
  }
}
