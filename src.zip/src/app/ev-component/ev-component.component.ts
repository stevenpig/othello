import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ev-component',
  templateUrl: './ev-component.component.html',
  styleUrls: ['./ev-component.component.css']
})
export class EvComponentComponent implements OnInit {

  constructor() { }

  columnDefs = [
    {headerName: 'Make', field: 'make' },
    {headerName: 'Model', field: 'model' },
    {headerName: 'Price', field: 'price'}
  ];

  rowData = [      { make: 'Toyota', model: 'Celica1', price: 999 },
    { make: 'Ford', model: 'Mondeo1', price: 999 },
    { make: 'Porsche', model: 'Boxter1', price: 999 }];
  private gridApi;
  private gridColumnApi;

  rowSelection: string;

  ngOnInit() {
    console.log('EvComponentComponent');
    this.rowSelection = 'single';
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }


  onAddRow() {
    var newItem = { make: 'fdasfsda', model: 'Cel111ica1', price: 999 };
    var res = this.gridApi.updateRowData({ add: [newItem] });

  }
}
