import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EvComponentComponent } from './ev-component.component';

describe('EvComponentComponent', () => {
  let component: EvComponentComponent;
  let fixture: ComponentFixture<EvComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EvComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EvComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
