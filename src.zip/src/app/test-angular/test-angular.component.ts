import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-angular',
  templateUrl: './test-angular.component.html',
  styleUrls: ['./test-angular.component.css']
})
export class TestAngularComponent implements OnInit {

  title: string;
  constructor() { }

  ngOnInit() {
    this.title = 'a';
  }

}
