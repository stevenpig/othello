import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {DatePipe} from '@angular/common';

@Component({
  selector: 'app-test-angular',
  templateUrl: './test-angular.component.html',
  styleUrls: ['./test-angular.component.css']
})
export class TestAngularComponent implements OnInit {

  @Input()
  title: string;

  @Input()
  case: boolean

  @Output()
  out = new EventEmitter<string>();

  newDate: Date|string;


  constructor() { }

  ngOnInit() {
    alert(this.case);

    const d = new Date();
    const dp = new DatePipe(navigator.language);
    dp.transform(d);
    console.log(d);
    console.log(    dp.transform(d));
    const e = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    console.log(e.toISOString());

    this.newDate = '7/16/2018';
    console.log(this.newDate);

    this.newDate = new Date();
    console.log(this.newDate);

  }

  test() {
    this.out.emit('id');
  }

}
