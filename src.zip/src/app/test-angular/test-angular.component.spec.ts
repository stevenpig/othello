import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestAngularComponent } from './test-angular.component';

class MockUserService {
  isLoggedIn = true;
  user = { name: 'Test User'};
}

describe('TestAngularComponent', () => {
  let component: TestAngularComponent;
  let fixture: ComponentFixture<TestAngularComponent>;



  beforeEach(async(() => {

    TestBed.configureTestingModule({
      declarations: [ TestAngularComponent ],

    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestAngularComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  /*
  it('should have one p', () => {
    const bannerElement: HTMLElement = fixture.nativeElement;
    const p = bannerElement.querySelector('p');
    expect(p.textContent).toContain('test-angular works!');
  });
  */

  it('dynamic title', () => {
    const te: HTMLElement = fixture.nativeElement;
    const t = te.querySelector('h1');
    component.title = 'b';
    fixture.detectChanges();
    expect(t.textContent).toContain('b');
  });
});
