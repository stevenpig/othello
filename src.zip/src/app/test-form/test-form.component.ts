import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';

@Component({
  selector: 'app-test-form',
  templateUrl: './test-form.component.html',
  styleUrls: ['./test-form.component.css']
})
export class TestFormComponent implements OnInit {

  filteredOptions: Observable<string[]>;

  filteredOptions1: Observable<any[]>;

  form: FormGroup;

  constructor(private fb: FormBuilder) {


  }

  options: string[] = ['One', 'Two', 'Three'];

  options1: any[] = [
    {name: 'One1', key: 'One'},
    {name: 'Two1', key: 'Two'},
    {name: 'Three1', key: 'Three'}
    ];

  ngOnInit() {

    this.form = this.fb.group({
      name: '', // <--- the FormControl called "name"
      name1: ''
    });

    this.filteredOptions = this.form.get('name').valueChanges
      .pipe(
        startWith(''),
        map(opt => opt ? this.filterOption(opt) : this.options.slice())
      );

    this.filteredOptions1 = this.form.get('name1').valueChanges
      .pipe(
        startWith(''),
        map(opt => opt ? this.filterOption1(opt) : this.resetOptions1())
      );

  }

  filterOption(value: any): string[] {
    const filterValue = value.toLowerCase();
    this.form.get('name1').reset('');


    return this.options.filter(opt => opt.toLowerCase().indexOf(filterValue) === 0);
  }

  filterOption1(value: any): any[] {
    const filterValue = value.toLowerCase();
    const key = this.form.get('name').value;

    if (key)
      return this.options1.filter(opt => opt.key === key &&  opt.name.toLowerCase().indexOf(filterValue) === 0);
    else
      return this.options1.filter(opt => opt.name.toLowerCase().indexOf(filterValue) === 0);
  }

  resetOptions1(): any[] {

    const key = this.form.get('name').value;

    if (key) {
      return this.options1.filter(opt => opt.key === key);
    } else {
      return this.options1.slice();
    }

  }
}
