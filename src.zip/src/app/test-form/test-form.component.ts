import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {Observable, of} from 'rxjs';
import {map, startWith} from 'rxjs/operators';

@Component({
  selector: 'app-test-form',
  templateUrl: './test-form.component.html',
  styleUrls: ['./test-form.component.css']
})
export class TestFormComponent implements OnInit {

  filteredOptions: Observable<any[]>;

  filteredOptions1: Observable<any[]>;

  form: FormGroup;

  constructor(private fb: FormBuilder) {


  }

  options: any[] = [
    {name: 'One', key: 'One1'},
    {name: 'Two', key: 'Two1'},
    {name: 'Three', key: 'Three1'}];

  options1: any[] = [
    {name: 'One1', key: 'One'},
    {name: 'Two1', key: 'Two'},
    {name: 'Three1', key: 'Three'}
    ];

  ngOnInit() {

    this.form = this.fb.group({
      name: '', // <--- the FormControl called "name"
      name1: ''
    });


    this.filteredOptions = this.form.get('name').valueChanges
      .pipe(
        startWith(''),
        map(opt => opt ? this.filterOption(opt) : this.options.slice())
      );

    this.filteredOptions1 = this.form.get('name1').valueChanges
      .pipe(
        startWith(''),
        map(opt => opt ? this.filterOption1(opt) : this.resetOptions1())

      );
  }

  filterOption(value: any): any[] {
    const filterValue = value.name ? value.name.toLowerCase() : value.toLowerCase();
    return this.options.filter(opt => opt.name.toLowerCase().indexOf(filterValue) === 0);
  }

  filterOption1(value: any): any[] {
    const filterValue = value.name ? value.name.toLowerCase() : value.toLowerCase();
    const key = this.form.get('name').value.name;

    if (key)
      return this.options1.filter(opt => opt.key === key &&  opt.name.toLowerCase().indexOf(filterValue) === 0);
    else {
      return this.options1.filter(opt => opt.name.toLowerCase().indexOf(filterValue) === 0);
    }

  }

  resetOptions1(): any[] {

    const key = this.form.get('name').value.name;

    if (key) {
      return this.options1.filter(opt => opt.key === key);
    } else {
      return this.options1.slice();
    }

  }

  option1Select(data: any): void {
    this.form.get('name1').reset('');
  }


  optionSelect(data: any): void {
    this.form.get('name').reset(data.option.value.key, {
      emitEvent: false
    });
  }
}
