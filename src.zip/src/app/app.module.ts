import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';

import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatTreeModule} from '@angular/material/tree';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatIconModule} from '@angular/material/icon';
import { TestAngularComponent } from './test-angular/test-angular.component';
import { MetricsMainComponent } from './metrics-main/metrics-main.component';
import {
  MatAutocompleteModule,
  MatButtonModule,
  MatDialogModule, MatFormFieldModule, MatInputModule,
  MatMenuModule, MatSidenavModule,
  MatTabsModule,
  MatToolbarModule
} from '@angular/material';
import {DynamicTabsDirective} from './tab/dynamic-tabs.directive';
import {TabsComponent} from './tab/tabs.component';
import {TabComponent} from './tab/tab.component';
import {ProductComponent, ProductEditDialogComponent, ProductSearchDialogComponent} from './product/product.component';
import { EvComponentComponent } from './ev-component/ev-component.component';
import {AgGridModule} from 'ag-grid-angular';
import { TestFormComponent } from './test-form/test-form.component';

@NgModule({
  declarations: [
    AppComponent,
    TestAngularComponent,
    MetricsMainComponent,
    DynamicTabsDirective,
    TabsComponent,
    ProductComponent,
    EvComponentComponent,
    TabComponent,
    ProductSearchDialogComponent,
    ProductEditDialogComponent,
    TestFormComponent

  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    FormsModule,
    HttpClientModule,
    MatTreeModule,
    MatCheckboxModule,
    MatIconModule,
    MatToolbarModule,
    MatTabsModule,
    MatMenuModule,
    MatButtonModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    AgGridModule.withComponents([]),
    ReactiveFormsModule,
    MatSidenavModule,
    MatAutocompleteModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [ProductComponent, EvComponentComponent, ProductSearchDialogComponent, ProductEditDialogComponent]
})
export class AppModule { }
